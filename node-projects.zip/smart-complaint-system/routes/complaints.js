const express = require("express");
const Complaint = require("../models/Complaint");
const { protect, allowRoles } = require("../middleware/auth");
const upload = require("../middleware/upload");
const sendEmail = require("../utils/sendEmail");

const router = express.Router();

// POST /api/complaints  -> file a new complaint (with optional image)
// In Postman: Body -> form-data. Fields: title, description, category, image (File)
router.post("/", protect, upload.single("image"), async (req, res) => {
  try {
    const { title, description, category } = req.body || {};
    if (!title || !description) {
      return res.status(400).json({ message: "title and description are required" });
    }
    const complaint = await Complaint.create({
      title,
      description,
      category,
      image: req.file ? `/uploads/${req.file.filename}` : null,
      user: req.user._id,
    });

    sendEmail(
      req.user.email,
      "Complaint registered",
      `Hi ${req.user.name}, your complaint "${title}" was registered. Complaint ID: ${complaint._id}`
    );

    res.status(201).json(complaint);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/complaints/my  -> complaints filed by the logged-in user
router.get("/my", protect, async (req, res) => {
  try {
    const complaints = await Complaint.find({ user: req.user._id })
      .sort({ createdAt: -1 })
      .populate("assignedTo", "name email");
    res.json(complaints);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/complaints/assigned  -> complaints assigned to the logged-in staff member
router.get("/assigned", protect, allowRoles("staff"), async (req, res) => {
  try {
    const complaints = await Complaint.find({ assignedTo: req.user._id })
      .sort({ createdAt: -1 })
      .populate("user", "name email");
    res.json(complaints);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/complaints/:id  -> track one complaint (owner, assigned staff or admin only)
router.get("/:id", protect, async (req, res) => {
  try {
    const complaint = await Complaint.findById(req.params.id)
      .populate("user", "name email")
      .populate("assignedTo", "name email");
    if (!complaint) return res.status(404).json({ message: "Complaint not found" });

    const me = req.user._id.toString();
    const allowed =
      req.user.role === "admin" ||
      complaint.user._id.toString() === me ||
      (complaint.assignedTo && complaint.assignedTo._id.toString() === me);
    if (!allowed) return res.status(403).json({ message: "Not your complaint" });

    res.json(complaint);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// PUT /api/complaints/:id/status  -> staff/admin update the status
// body: { "status": "In Progress" } or { "status": "Resolved" }
router.put("/:id/status", protect, allowRoles("staff", "admin"), async (req, res) => {
  try {
    const { status } = req.body || {};
    if (!["In Progress", "Resolved"].includes(status)) {
      return res.status(400).json({ message: 'status must be "In Progress" or "Resolved"' });
    }
    const complaint = await Complaint.findById(req.params.id).populate("user", "name email");
    if (!complaint) return res.status(404).json({ message: "Complaint not found" });

    // Staff can only update complaints assigned to them
    if (
      req.user.role === "staff" &&
      (!complaint.assignedTo || complaint.assignedTo.toString() !== req.user._id.toString())
    ) {
      return res.status(403).json({ message: "This complaint is not assigned to you" });
    }

    complaint.status = status;
    if (status === "Resolved") complaint.resolvedAt = new Date();
    await complaint.save();

    sendEmail(
      complaint.user.email,
      "Complaint status updated",
      `Hi ${complaint.user.name}, the status of your complaint "${complaint.title}" is now: ${status}.`
    );

    res.json(complaint);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
