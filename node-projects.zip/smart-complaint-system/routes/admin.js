const express = require("express");
const Complaint = require("../models/Complaint");
const User = require("../models/User");
const { protect, allowRoles } = require("../middleware/auth");
const sendEmail = require("../utils/sendEmail");

const router = express.Router();

// Every route in this file needs a logged-in admin
router.use(protect, allowRoles("admin"));

// GET /api/admin/complaints?status=Pending  -> all complaints (optional filter)
router.get("/complaints", async (req, res) => {
  try {
    const filter = {};
    if (req.query.status) filter.status = req.query.status;
    const complaints = await Complaint.find(filter)
      .sort({ createdAt: -1 })
      .populate("user", "name email")
      .populate("assignedTo", "name email");
    res.json(complaints);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/admin/staff  -> list staff members (so admin knows whom to assign)
router.get("/staff", async (req, res) => {
  try {
    res.json(await User.find({ role: "staff" }).select("-password"));
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// PUT /api/admin/complaints/:id/assign   body: { "staffId": "<staff user id>" }
router.put("/complaints/:id/assign", async (req, res) => {
  try {
    const { staffId } = req.body || {};
    const staff = await User.findOne({ _id: staffId, role: "staff" });
    if (!staff) return res.status(400).json({ message: "Valid staffId is required" });

    const complaint = await Complaint.findById(req.params.id).populate("user", "name email");
    if (!complaint) return res.status(404).json({ message: "Complaint not found" });

    complaint.assignedTo = staff._id;
    complaint.status = "Assigned";
    await complaint.save();

    sendEmail(staff.email, "New complaint assigned", `Complaint "${complaint.title}" is assigned to you.`);
    sendEmail(
      complaint.user.email,
      "Complaint assigned",
      `Your complaint "${complaint.title}" has been assigned to ${staff.name}.`
    );

    res.json(complaint);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/admin/analytics  -> numbers for the admin dashboard
router.get("/analytics", async (req, res) => {
  try {
    const total = await Complaint.countDocuments();

    // Group complaints by status and count them
    const statusRows = await Complaint.aggregate([{ $group: { _id: "$status", count: { $sum: 1 } } }]);
    const byStatus = { Pending: 0, Assigned: 0, "In Progress": 0, Resolved: 0 };
    statusRows.forEach((r) => (byStatus[r._id] = r.count));

    // Group by category
    const categoryRows = await Complaint.aggregate([{ $group: { _id: "$category", count: { $sum: 1 } } }]);
    const byCategory = {};
    categoryRows.forEach((r) => (byCategory[r._id] = r.count));

    const resolutionRate = total === 0 ? 0 : Math.round((byStatus.Resolved / total) * 100);

    res.json({ total, byStatus, byCategory, resolutionRatePercent: resolutionRate });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
