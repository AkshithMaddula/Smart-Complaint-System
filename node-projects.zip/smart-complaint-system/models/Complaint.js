const mongoose = require("mongoose");

const complaintSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    description: { type: String, required: true },
    category: {
      type: String,
      enum: ["Water", "Electricity", "Road", "Sanitation", "Other"],
      default: "Other",
    },
    image: { type: String, default: null }, // path of the uploaded image
    status: {
      type: String,
      enum: ["Pending", "Assigned", "In Progress", "Resolved"],
      default: "Pending",
    },
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true }, // who filed it
    assignedTo: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null }, // staff member
    resolvedAt: { type: Date, default: null },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Complaint", complaintSchema);
