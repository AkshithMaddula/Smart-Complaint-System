const nodemailer = require("nodemailer");

// Sends an email. If email is not configured, it just prints a message,
// so the app still works without any email setup.
async function sendEmail(to, subject, text) {
  if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS) {
    console.log(`[email skipped - not configured] To: ${to} | ${subject}`);
    return;
  }
  try {
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: { user: process.env.EMAIL_USER, pass: process.env.EMAIL_PASS },
    });
    await transporter.sendMail({
      from: `"Complaint System" <${process.env.EMAIL_USER}>`,
      to,
      subject,
      text,
    });
  } catch (err) {
    console.error("Email failed:", err.message); // never crash the API because of email
  }
}

module.exports = sendEmail;
