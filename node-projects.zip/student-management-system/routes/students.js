const express = require("express");
const User = require("../models/User");
const Student = require("../models/Student");
const { protect, allowRoles } = require("../middleware/auth");

const router = express.Router();

// GET /api/students/me  -> a student views ONLY their own record
router.get("/me", protect, allowRoles("student"), async (req, res) => {
  try {
    const student = await Student.findOne({ user: req.user._id });
    if (!student) return res.status(404).json({ message: "Student record not found" });
    res.json(student);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ---- Everything below is ADMIN only ----

// CREATE: POST /api/students
// Creates the login account (User) AND the student record together.
router.post("/", protect, allowRoles("admin"), async (req, res) => {
  try {
    const { name, email, password, rollNo, course, year, phone } = req.body || {};
    if (!name || !email || !password || !rollNo || !course || !year) {
      return res
        .status(400)
        .json({ message: "name, email, password, rollNo, course and year are required" });
    }
    if (await User.findOne({ email: email.toLowerCase() })) {
      return res.status(400).json({ message: "Email already exists" });
    }
    if (await Student.findOne({ rollNo })) {
      return res.status(400).json({ message: "Roll number already exists" });
    }

    const user = await User.create({ name, email, password, role: "student" });
    try {
      const student = await Student.create({ name, email, rollNo, course, year, phone, user: user._id });
      res.status(201).json(student);
    } catch (err) {
      await User.findByIdAndDelete(user._id); // undo the login account if student creation failed
      throw err;
    }
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// READ ALL: GET /api/students?search=ravi&course=CSE&page=1&limit=10
router.get("/", protect, allowRoles("admin"), async (req, res) => {
  try {
    const { search, course } = req.query;
    const page = Math.max(Number(req.query.page) || 1, 1);
    const limit = Math.min(Number(req.query.limit) || 10, 100);

    const filter = {};
    if (course) filter.course = course;
    if (search) {
      const safe = search.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); // escape special characters
      filter.$or = [
        { name: { $regex: safe, $options: "i" } },
        { rollNo: { $regex: safe, $options: "i" } },
      ];
    }

    const total = await Student.countDocuments(filter);
    const students = await Student.find(filter)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit);

    res.json({ total, page, pages: Math.ceil(total / limit), students });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// READ ONE: GET /api/students/:id
router.get("/:id", protect, allowRoles("admin"), async (req, res) => {
  try {
    const student = await Student.findById(req.params.id);
    if (!student) return res.status(404).json({ message: "Student not found" });
    res.json(student);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// UPDATE: PUT /api/students/:id   (only these fields can be changed)
router.put("/:id", protect, allowRoles("admin"), async (req, res) => {
  try {
    const updates = {};
    ["name", "rollNo", "course", "year", "phone"].forEach((field) => {
      if (req.body && req.body[field] !== undefined) updates[field] = req.body[field];
    });

    const student = await Student.findByIdAndUpdate(req.params.id, updates, {
      new: true, // return the updated document
      runValidators: true,
    });
    if (!student) return res.status(404).json({ message: "Student not found" });

    if (updates.name) await User.findByIdAndUpdate(student.user, { name: updates.name });
    res.json(student);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// DELETE: DELETE /api/students/:id  (removes the record and the login account)
router.delete("/:id", protect, allowRoles("admin"), async (req, res) => {
  try {
    const student = await Student.findById(req.params.id);
    if (!student) return res.status(404).json({ message: "Student not found" });
    await User.findByIdAndDelete(student.user);
    await student.deleteOne();
    res.json({ message: "Student deleted" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
