const jwt = require("jsonwebtoken");
const User = require("../models/User");

// protect: checks the JWT token and finds the logged-in user
exports.protect = async (req, res, next) => {
  const header = req.headers.authorization; // "Bearer <token>"
  if (!header || !header.startsWith("Bearer ")) {
    return res.status(401).json({ message: "No token, access denied" });
  }
  try {
    const decoded = jwt.verify(header.split(" ")[1], process.env.JWT_SECRET);
    req.user = await User.findById(decoded.id).select("-password");
    if (!req.user) return res.status(401).json({ message: "User no longer exists" });
    next();
  } catch (err) {
    res.status(401).json({ message: "Invalid or expired token" });
  }
};

// allowRoles: role-based access control, e.g. allowRoles("admin")
exports.allowRoles = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user.role)) {
    return res.status(403).json({ message: "You are not allowed to do this" });
  }
  next();
};
