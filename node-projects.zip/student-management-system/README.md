# Student Management System (Node.js + Express + MongoDB)

Admin manages student records (full CRUD). Students can log in and see only their own record.

## Run it
1. Install Node.js and MongoDB (or use a free MongoDB Atlas URI).
2. In this folder:
   ```
   npm install
   copy .env.example to .env
   npm run seed        (creates admin@example.com / admin123)
   npm run dev
   ```

## Test in Postman (in this order)
| # | Request | Notes |
|---|---------|-------|
| 1 | POST /api/auth/login | `{ "email": "admin@example.com", "password": "admin123" }` -> copy token |
| 2 | POST /api/students | Header `Authorization: Bearer <token>`. Body: name, email, password, rollNo, course, year, phone |
| 3 | GET /api/students | optional `?search=ravi&course=CSE&page=1&limit=10` |
| 4 | GET /api/students/:id | one student |
| 5 | PUT /api/students/:id | send only the fields to change, e.g. `{ "course": "IT" }` |
| 6 | POST /api/auth/login with the student's email/password | student token |
| 7 | GET /api/students/me | the student sees only their own record |
| 8 | GET /api/students with the student token | 403, students can't see everyone (this shows RBAC) |
| 9 | DELETE /api/students/:id | admin token |

## Folder map
- `server.js`, `config/db.js`
- `models/User.js` (login account + role), `models/Student.js` (the record)
- `routes/auth.js` (login), `routes/students.js` (CRUD)
- `middleware/auth.js` (JWT check + role check)

## How to explain it in the interview
- **CRUD:** Create = POST, Read = GET, Update = PUT, Delete = DELETE.
- **Role-based access control:** two roles, admin and student. A middleware checks the role from the logged-in user and returns 403 if it doesn't match.
- **Why two collections?** `User` is for login, `Student` is for academic details, linked by the `user` id.
- **MongoDB:** documents stored as JSON-like objects; Mongoose gives them a schema and validation.
- **Search and pagination:** `regex` for search, `skip` and `limit` so we never load thousands of students at once.
