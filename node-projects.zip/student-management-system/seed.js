// Run once:  npm run seed   -> creates the admin account
require("dotenv").config();
const mongoose = require("mongoose");
const User = require("./models/User");

(async () => {
  await mongoose.connect(process.env.MONGO_URI);
  const email = "admin@example.com";
  if (await User.findOne({ email })) console.log("Admin already exists");
  else {
    await User.create({ name: "Admin", email, password: "admin123", role: "admin" });
    console.log("Created admin:", email, "/ admin123");
  }
  await mongoose.disconnect();
})();
