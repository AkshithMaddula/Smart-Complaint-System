const mongoose = require("mongoose");

// A Student is the actual record (roll number, course...). It links to a User login.
const studentSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    rollNo: { type: String, required: true, unique: true, trim: true },
    course: { type: String, required: true, trim: true },
    year: { type: Number, required: true, min: 1, max: 6 },
    phone: { type: String, trim: true },
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Student", studentSchema);
